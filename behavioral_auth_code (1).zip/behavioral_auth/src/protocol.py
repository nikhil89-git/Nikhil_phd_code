"""
Evaluation protocol: indexing of the publicly labeled test sessions and
the session-level calibration/test partition.

The 816 publicly labeled Balabit test sessions are split, at the level of
whole sessions, into a calibration partition and a test partition. The
split is stratified by (claimed account, genuine/impostor label) so that
both partitions contain every account and both kinds of trial. Neither
partition is used to fit the classifier or the normalization statistics.
The decision threshold is selected on the calibration partition only, and
all reported error rates are measured on the test partition.
"""

import os

import numpy as np
import pandas as pd

from .data_loader import list_session_files


def labeled_test_sessions(data_root, users):
    """Return a list of (path, claimed_user, is_impostor) for every test
    session that has a publicly released ground-truth label."""
    labels = (pd.read_csv(os.path.join(data_root, "public_labels.csv"))
              .set_index("filename")["is_illegal"].to_dict())
    test_dir = os.path.join(data_root, "test_files")
    sessions = []
    for user in users:
        for path in list_session_files(test_dir, user):
            name = os.path.basename(path)
            if name in labels:
                sessions.append((path, user, bool(labels[name] == 1)))
    return sessions


def stratified_session_split(sessions, seed, calibration_fraction=0.5):
    """Split sessions into calibration and test index arrays.

    Sessions are grouped by (claimed account, impostor flag); within each
    group a random fraction (rounded down) is assigned to calibration and
    the remainder to test.
    """
    rng = np.random.default_rng(seed)
    groups = {}
    for idx, (_, user, is_impostor) in enumerate(sessions):
        groups.setdefault((user, is_impostor), []).append(idx)

    calibration, test = [], []
    for key in sorted(groups, key=str):
        members = list(groups[key])
        rng.shuffle(members)
        n_cal = int(len(members) * calibration_fraction)
        calibration.extend(members[:n_cal])
        test.extend(members[n_cal:])
    return np.array(sorted(calibration)), np.array(sorted(test))
