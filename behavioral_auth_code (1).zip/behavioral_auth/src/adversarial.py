"""
Adversarial risk estimation for rejected attempts (Section 14 of the
manuscript).

For a normalized feature vector z with claimed identity k*, the model
assigns probability p = P(y = k* | z). The threshold slack is
psi = p - tau, which is negative for a rejected attempt.

  R_slack(z)  = 1 / (1 + exp(-c * psi))               analytical risk
  ASR(z)      = fraction of M perturbed copies z + eps, eps ~ U[-rho, rho]^d,
                that satisfy P(y = k* | z + eps) >= tau
  R_attack(z) = 0.6 * R_slack(z) + 0.4 * ASR(z)         combined risk

R_slack increases as an attempt approaches the acceptance boundary
(psi -> 0) and is small for confidently rejected attempts (psi << 0).
"""

import numpy as np

from .model import softmax

RHO = 0.15
N_SAMPLES = 200
SLACK_SCALE = 12.0
RISK_WEIGHTS = (0.6, 0.4)
_CHUNK = 400


def slack_risk(psi, c=SLACK_SCALE):
    return 1.0 / (1.0 + np.exp(-c * np.asarray(psi, dtype=float)))


def monte_carlo(Z, claimed_idx, model, tau, rng, rho=RHO, n_samples=N_SAMPLES):
    """Perturbation test for every row of Z (all attempts of one claimed
    identity).

    Returns
    -------
    p0 : probability of the claimed identity for the unperturbed attempt
    asr : fraction of perturbed copies accepted at threshold tau
    max_change : largest |P(z + eps) - P(z)| over the perturbed copies
    """
    n, d = Z.shape
    p0 = model.predict_proba(Z)[:, claimed_idx]
    asr = np.empty(n)
    max_change = np.empty(n)
    for start in range(0, n, _CHUNK):
        block = Z[start:start + _CHUNK]
        eps = rng.uniform(-rho, rho, size=(n_samples, len(block), d))
        logits = (block[None, :, :] + eps) @ model.W.T + model.b
        p = softmax(logits)[:, :, claimed_idx]
        asr[start:start + _CHUNK] = (p >= tau).mean(axis=0)
        max_change[start:start + _CHUNK] = np.abs(p - p0[None, start:start + _CHUNK]).max(axis=0)
    return p0, asr, max_change


def combined_risk(psi, asr, weights=RISK_WEIGHTS, c=SLACK_SCALE):
    return weights[0] * slack_risk(psi, c) + weights[1] * np.asarray(asr)


def weight_row_sum_norm(W):
    """Maximum absolute row sum of the weight matrix, ||W||_inf."""
    return float(np.max(np.sum(np.abs(W), axis=1)))
