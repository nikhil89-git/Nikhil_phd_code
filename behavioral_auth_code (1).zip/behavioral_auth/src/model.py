"""
Feature normalization and the linear softmax authentication model.

Implements Equations (8)-(17) of the manuscript:
  - z-score normalization using training-set statistics
  - softmax classifier over K enrolled identities
  - cross-entropy training objective
  - batch gradient descent with a decaying learning rate
"""

import numpy as np


class Normalizer:
    """Per-dimension z-score normalization, fit on training data only."""

    def __init__(self):
        self.mu = None
        self.sigma = None

    def fit(self, X):
        self.mu = X.mean(axis=0)
        sigma = X.std(axis=0)
        sigma[sigma == 0] = 1e-8
        self.sigma = sigma
        return self

    def transform(self, X):
        return (X - self.mu) / self.sigma


def softmax(logits):
    shifted = logits - logits.max(axis=-1, keepdims=True)
    exp = np.exp(shifted)
    return exp / exp.sum(axis=-1, keepdims=True)


def entropy(P):
    """Shannon entropy of each row of a probability matrix P (Equation 21)."""
    return -np.sum(P * np.log(np.clip(P, 1e-12, 1.0)), axis=-1)


class SoftmaxAuthenticator:
    """Linear softmax classifier used as the authentication model.

    Parameters
    ----------
    n_features : int
        Feature dimensionality (8 in the manuscript).
    n_classes : int
        Number of enrolled identities K.
    """

    def __init__(self, n_features, n_classes):
        self.W = np.zeros((n_classes, n_features))
        self.b = np.zeros(n_classes)
        self.n_classes = n_classes

    def predict_proba(self, Z):
        logits = Z @ self.W.T + self.b
        return softmax(logits)

    def fit(self, Z_train, y_train, Z_val=None, y_val=None,
            eta0=0.5, decay=0.01, n_epochs=400, log_every=10):
        """Batch gradient descent on the cross-entropy objective.

        Returns a per-epoch history dict (recorded every `log_every`
        iterations) with training/validation loss and accuracy.
        """
        n_samples = Z_train.shape[0]
        Y_onehot = np.zeros((n_samples, self.n_classes))
        Y_onehot[np.arange(n_samples), y_train] = 1.0

        history = {"epoch": [], "train_loss": [], "val_loss": [],
                   "train_acc": [], "val_acc": []}

        for epoch in range(n_epochs):
            P = self.predict_proba(Z_train)
            grad_logits = P - Y_onehot
            grad_W = (grad_logits.T @ Z_train) / n_samples
            grad_b = grad_logits.mean(axis=0)

            eta = eta0 / (1 + decay * epoch)
            self.W -= eta * grad_W
            self.b -= eta * grad_b

            if epoch % log_every == 0 or epoch == n_epochs - 1:
                train_loss = _cross_entropy(P, y_train)
                train_acc = float((P.argmax(axis=1) == y_train).mean())
                history["epoch"].append(epoch)
                history["train_loss"].append(train_loss)
                history["train_acc"].append(train_acc)
                if Z_val is not None:
                    P_val = self.predict_proba(Z_val)
                    history["val_loss"].append(_cross_entropy(P_val, y_val))
                    history["val_acc"].append(
                        float((P_val.argmax(axis=1) == y_val).mean()))
        return history

    def save(self, path):
        np.savez(path, W=self.W, b=self.b)

    @classmethod
    def load(cls, path):
        data = np.load(path)
        model = cls(data["W"].shape[1], data["W"].shape[0])
        model.W = data["W"]
        model.b = data["b"]
        return model


def _cross_entropy(P, y_true):
    n = len(y_true)
    log_likelihood = np.log(np.clip(P[np.arange(n), y_true], 1e-12, 1.0))
    return float(-np.mean(log_likelihood))
