"""
Feature extraction for the eight-dimensional behavioral feature vector:

    x = [T, L, V_mean, V_std, R1, R2, R3, R4]

T        : attempt duration (seconds)
L        : cumulative cursor path length (pixels)
V_mean   : mean instantaneous velocity (pixels/second)
V_std    : standard deviation of instantaneous velocity (pixels/second)
R1..R4   : fraction of recorded samples in each of the four screen
           quadrants, split at a fixed (x_mid, y_mid) reference point

These definitions correspond directly to Equations (3)-(7) of the
manuscript. R1-R4 are computed relative to screen quadrants rather
than the four regions of the manuscript's proposed graphical-password
interface, since this dataset was collected from continuous
remote-desktop interaction rather than that interface directly; see
Section 6 of the manuscript for the justification.
"""

import numpy as np

N_FEATURES = 8


def extract_features(segment, x_mid, y_mid):
    """Compute the eight-dimensional feature vector for one attempt.

    Parameters
    ----------
    segment : pandas.DataFrame
        One attempt, as returned by `segment_into_attempts`, with
        columns "client timestamp", "x", "y".
    x_mid, y_mid : float
        Reference coordinates splitting the screen into four quadrants.

    Returns
    -------
    numpy.ndarray of shape (8,), or None if the segment is unusable.
    """
    t = segment["client timestamp"].to_numpy(dtype=float)
    x = segment["x"].to_numpy(dtype=float)
    y = segment["y"].to_numpy(dtype=float)
    n = len(t)
    if n < 3:
        return None

    duration = t[-1] - t[0]
    if duration <= 0:
        return None

    dx = np.diff(x)
    dy = np.diff(y)
    step_distances = np.sqrt(dx ** 2 + dy ** 2)
    path_length = float(np.sum(step_distances))

    dt = np.diff(t)
    valid_steps = dt > 0
    if valid_steps.sum() < 2:
        return None
    velocity = step_distances[valid_steps] / dt[valid_steps]
    velocity_mean = float(np.mean(velocity))
    velocity_std = float(np.std(velocity))

    in_q1 = (x < x_mid) & (y >= y_mid)
    in_q2 = (x >= x_mid) & (y >= y_mid)
    in_q3 = (x < x_mid) & (y < y_mid)
    in_q4 = (x >= x_mid) & (y < y_mid)
    r1, r2, r3, r4 = (in_q1.sum() / n, in_q2.sum() / n,
                      in_q3.sum() / n, in_q4.sum() / n)

    feature_vector = np.array(
        [duration, path_length, velocity_mean, velocity_std, r1, r2, r3, r4],
        dtype=float,
    )
    if not np.all(np.isfinite(feature_vector)):
        return None
    return feature_vector


def build_feature_matrix(sessions, user_to_label, x_mid, y_mid, segmenter):
    """Extract features for every attempt across a list of
    (session_path, user) pairs.

    Parameters
    ----------
    sessions : list of (str, str)
        (file path, user id) pairs.
    user_to_label : dict
        Maps user id to integer class label.
    x_mid, y_mid : float
        Quadrant reference coordinates.
    segmenter : callable
        Function mapping a session file path to a list of attempt
        segments (see `data_loader.load_session` +
        `data_loader.segment_into_attempts`).

    Returns
    -------
    (numpy.ndarray, numpy.ndarray)
        Feature matrix of shape (n_attempts, 8) and integer label
        vector of shape (n_attempts,).
    """
    rows, labels = [], []
    for path, user in sessions:
        for segment in segmenter(path):
            feature_vector = extract_features(segment, x_mid, y_mid)
            if feature_vector is not None:
                rows.append(feature_vector)
                labels.append(user_to_label[user])
    return np.array(rows), np.array(labels)
