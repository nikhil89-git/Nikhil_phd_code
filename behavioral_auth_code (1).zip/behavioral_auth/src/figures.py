"""
Figure generation. All figures are written as vector PDF files with
embedded TrueType fonts.
"""

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

plt.rcParams.update({
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "font.size": 9,
    "axes.titlesize": 9,
    "axes.labelsize": 9,
    "legend.fontsize": 8,
})


def plot_training_curve(history, out_path):
    fig, ax = plt.subplots(figsize=(5.2, 3.6))
    ax.plot(history["epoch"], history["train_loss"], label="Training loss")
    ax.plot(history["epoch"], history["val_loss"],
            label="Validation loss (session-disjoint)")
    ax.set_xlabel("Epoch")
    ax.set_ylabel("Cross-entropy loss")
    ax.legend(loc="upper right")
    fig.tight_layout()
    fig.savefig(out_path)
    plt.close(fig)


def plot_pca_projection(Z, y, out_path, seed, points_per_class=150,
                        clip_percentiles=(1, 99)):
    rng = np.random.default_rng(seed)
    n_classes = int(y.max()) + 1
    keep = []
    for k in range(n_classes):
        members = np.where(y == k)[0]
        keep.append(rng.choice(members, size=min(points_per_class, len(members)),
                               replace=False))
    keep = np.concatenate(keep)
    Zs, ys = Z[keep], y[keep]

    centered = Zs - Zs.mean(axis=0)
    eigvals, eigvecs = np.linalg.eigh(np.cov(centered, rowvar=False))
    order = np.argsort(eigvals)[::-1]
    proj = np.column_stack([centered @ eigvecs[:, order[0]],
                            centered @ eigvecs[:, order[1]]])

    fig, ax = plt.subplots(figsize=(5.6, 4.4))
    cmap = plt.get_cmap("tab10")
    for k in range(n_classes):
        mask = ys == k
        ax.scatter(proj[mask, 0], proj[mask, 1], s=7, alpha=0.55,
                   color=cmap(k % 10), label=f"identity {k + 1}", linewidths=0)

    x_lo, x_hi = np.percentile(proj[:, 0], clip_percentiles)
    y_lo, y_hi = np.percentile(proj[:, 1], clip_percentiles)
    pad_x, pad_y = 0.15 * (x_hi - x_lo), 0.15 * (y_hi - y_lo)
    n_outside = int(np.sum((proj[:, 0] < x_lo) | (proj[:, 0] > x_hi) |
                           (proj[:, 1] < y_lo) | (proj[:, 1] > y_hi)))
    ax.set_xlim(x_lo - pad_x, x_hi + pad_x)
    ax.set_ylim(y_lo - pad_y, y_hi + pad_y)
    ax.set_xlabel("PC1")
    ax.set_ylabel("PC2")
    ax.legend(ncol=5, loc="upper center", bbox_to_anchor=(0.5, -0.14), fontsize=7,
              markerscale=1.8, frameon=False, columnspacing=1.0, handletextpad=0.2)
    fig.tight_layout()
    fig.savefig(out_path, bbox_inches="tight")
    plt.close(fig)
    return {"n_points": int(len(proj)), "n_outside_view": n_outside}


def plot_entropy_vs_probability(probs, ent, out_path, k_classes):
    fig, ax = plt.subplots(figsize=(5.2, 3.6))
    ax.scatter(probs, ent, s=5, alpha=0.3, linewidths=0, rasterized=False)
    ax.set_xlabel("Predicted probability of the claimed identity")
    ax.set_ylabel("Entropy of the output distribution (nats)")
    ax.axhline(np.log(k_classes), color="gray", linestyle=":", linewidth=0.8)
    fig.tight_layout()
    fig.savefig(out_path)
    plt.close(fig)


def plot_far_frr(test_curve, cal_curve, tau_star, out_path, tau_fixed=0.75):
    fig, ax = plt.subplots(figsize=(5.4, 3.8))
    t_t, far_t, frr_t = test_curve
    t_c, far_c, frr_c = cal_curve
    ax.plot(t_t, far_t * 100, color="tab:blue", label="FAR, test partition")
    ax.plot(t_t, frr_t * 100, color="tab:orange", label="FRR, test partition")
    ax.plot(t_c, far_c * 100, color="tab:blue", linestyle="--", linewidth=0.9,
            alpha=0.7, label="FAR, calibration partition")
    ax.plot(t_c, frr_c * 100, color="tab:orange", linestyle="--", linewidth=0.9,
            alpha=0.7, label="FRR, calibration partition")
    ax.axvline(tau_star, color="black", linewidth=0.9,
               label=f"calibrated threshold ({tau_star:.3f})")
    ax.axvline(tau_fixed, color="gray", linestyle=":", linewidth=1.2,
               label=f"fixed threshold ({tau_fixed:.2f})")
    ax.set_xlabel("Threshold")
    ax.set_ylabel("Error rate (%)")
    ax.set_xlim(0, 1)
    ax.set_ylim(-2, 102)
    ax.legend(loc="center", bbox_to_anchor=(0.5, 0.5), fontsize=7, frameon=True)
    fig.tight_layout()
    fig.savefig(out_path)
    plt.close(fig)


def plot_asr_histogram(asr_values, out_path):
    fig, ax = plt.subplots(figsize=(5.2, 3.4))
    weights = np.full(len(asr_values), 100.0 / len(asr_values))
    upper = max(0.2, float(np.ceil(asr_values.max() * 20) / 20))
    ax.hist(asr_values, bins=np.linspace(0, upper, 21), weights=weights,
            color="tab:blue", edgecolor="white", linewidth=0.5)
    ax.set_xlabel("Attack success rate of the perturbed copies (ASR)")
    ax.set_ylabel("Rejected impostor attempts (%)")
    ax.set_xlim(0, upper)
    fig.tight_layout()
    fig.savefig(out_path)
    plt.close(fig)
