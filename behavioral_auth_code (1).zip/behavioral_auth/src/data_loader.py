"""
Loading and segmentation of raw mouse-interaction session files.

Each session file is a CSV with columns:
    record timestamp, client timestamp, button, state, x, y

A session is segmented into discrete "attempts" at each left-button
click event, so that every attempt corresponds to the recorded cursor
trajectory between one click and the next (or between the start of
the session and the first click). This mirrors, on continuous
remote-desktop telemetry, the click-terminated interaction of the
proposed four-region graphical password interface: every attempt
ends in a click, exactly as a login attempt ends in a click on the
password image.
"""

import glob
import os

import pandas as pd

CLICK_STATES = ("Down", "Pressed")


def list_users(training_dir):
    return sorted(os.listdir(training_dir))


def list_session_files(root_dir, user):
    return sorted(glob.glob(os.path.join(root_dir, user, "session_*")))


def load_session(path):
    """Load one session file and sort it by client timestamp."""
    df = pd.read_csv(path)
    if df.empty:
        return df
    return df.sort_values("client timestamp").reset_index(drop=True)


def segment_into_attempts(df, min_points=8):
    """Split a loaded session into click-terminated attempt segments.

    Parameters
    ----------
    df : pandas.DataFrame
        A session loaded with `load_session`.
    min_points : int
        Minimum number of recorded points required for a segment to
        be considered a usable attempt.

    Returns
    -------
    list of pandas.DataFrame
        One entry per attempt, each a contiguous slice of `df`.
    """
    if df.empty:
        return []

    is_click = df["state"].isin(CLICK_STATES)
    click_indices = df.index[is_click].tolist()

    segments = []
    start = 0
    for click_idx in click_indices:
        if click_idx - start >= min_points:
            segments.append(df.iloc[start:click_idx + 1])
        start = click_idx + 1
    return segments


def compute_quadrant_midpoints(root_dir, users):
    """Compute the median x and y coordinate across all training
    sessions of the given users. Used to define the four screen
    quadrants that stand in for the four regions of the original
    graphical password interface (Equation 7 in the manuscript).
    """
    xs, ys = [], []
    for user in users:
        for path in list_session_files(root_dir, user):
            try:
                df = pd.read_csv(path, usecols=["x", "y"])
            except (ValueError, pd.errors.EmptyDataError):
                continue
            xs.append(df["x"])
            ys.append(df["y"])
    x_all = pd.concat(xs, ignore_index=True)
    y_all = pd.concat(ys, ignore_index=True)
    return float(x_all.median()), float(y_all.median())
