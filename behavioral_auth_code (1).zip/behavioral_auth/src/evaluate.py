"""
Verification metrics: false acceptance rate (FAR), false rejection rate
(FRR), equal error rate (EER), and half total error rate (HTER).

A trial is accepted when the probability assigned to the claimed identity
is at least the threshold tau (Equation (1) of the manuscript).

  FAR(tau) = fraction of impostor attempts with p >= tau
  FRR(tau) = fraction of genuine attempts with p <  tau
  HTER     = (FAR + FRR) / 2 at a fixed, pre-selected threshold

The threshold is selected on a calibration partition and then applied,
unchanged, to a disjoint test partition.
"""

import numpy as np


def far_frr(genuine, impostor, taus):
    """FAR and FRR at one or several thresholds (vectorized)."""
    taus = np.atleast_1d(np.asarray(taus, dtype=float))
    g = np.sort(genuine)
    i = np.sort(impostor)
    frr = np.searchsorted(g, taus, side="left") / len(g)
    far = 1.0 - np.searchsorted(i, taus, side="left") / len(i)
    return far, frr


def candidate_thresholds(genuine, impostor):
    return np.unique(np.concatenate([genuine, impostor, [0.0, 1.0]]))


def eer_point(genuine, impostor):
    """Threshold at which |FAR - FRR| is smallest, with the FAR/FRR
    values there and their mean (the EER estimate)."""
    taus = candidate_thresholds(genuine, impostor)
    far, frr = far_frr(genuine, impostor, taus)
    best = int(np.argmin(np.abs(far - frr)))
    return {
        "tau": float(taus[best]),
        "far": float(far[best]),
        "frr": float(frr[best]),
        "eer": float((far[best] + frr[best]) / 2.0),
    }


def operating_point(genuine, impostor, tau):
    far, frr = far_frr(genuine, impostor, tau)
    far, frr = float(far[0]), float(frr[0])
    return {
        "tau": float(tau),
        "far": far,
        "frr": frr,
        "hter": (far + frr) / 2.0,
        "genuine_accepted": int(np.sum(genuine >= tau)),
        "genuine_total": int(len(genuine)),
        "impostor_accepted": int(np.sum(impostor >= tau)),
        "impostor_total": int(len(impostor)),
    }


def curve(genuine, impostor, n_points=400):
    """FAR and FRR over a thinned grid of observed scores, for plotting."""
    taus = candidate_thresholds(genuine, impostor)
    if len(taus) > n_points:
        taus = taus[np.linspace(0, len(taus) - 1, n_points).astype(int)]
    far, frr = far_frr(genuine, impostor, taus)
    return taus, far, frr


def pool(session_scores, session_is_impostor, indices):
    """Concatenate per-session attempt scores into genuine / impostor
    arrays for the sessions listed in `indices`."""
    genuine = [session_scores[i] for i in indices if not session_is_impostor[i]]
    impostor = [session_scores[i] for i in indices if session_is_impostor[i]]
    return np.concatenate(genuine), np.concatenate(impostor)


def session_bootstrap(session_scores, session_is_impostor, indices, tau,
                      n_boot=2000, seed=0, level=0.95):
    """Percentile confidence intervals for FAR, FRR and HTER at a fixed
    threshold, resampling whole test sessions with replacement (attempts
    within a session are not independent)."""
    indices = np.asarray(indices)
    imp_acc = np.array([np.sum(session_scores[i] >= tau) if session_is_impostor[i] else 0
                        for i in indices], dtype=float)
    imp_n = np.array([len(session_scores[i]) if session_is_impostor[i] else 0
                      for i in indices], dtype=float)
    gen_rej = np.array([np.sum(session_scores[i] < tau) if not session_is_impostor[i] else 0
                        for i in indices], dtype=float)
    gen_n = np.array([len(session_scores[i]) if not session_is_impostor[i] else 0
                      for i in indices], dtype=float)

    rng = np.random.default_rng(seed)
    n = len(indices)
    far_s, frr_s = [], []
    for _ in range(n_boot):
        pick = rng.integers(0, n, size=n)
        far_s.append(imp_acc[pick].sum() / max(imp_n[pick].sum(), 1.0))
        frr_s.append(gen_rej[pick].sum() / max(gen_n[pick].sum(), 1.0))
    far_s, frr_s = np.array(far_s), np.array(frr_s)
    hter_s = (far_s + frr_s) / 2.0
    lo, hi = (1 - level) / 2 * 100, (1 + level) / 2 * 100
    return {
        "far_ci": [float(np.percentile(far_s, lo)), float(np.percentile(far_s, hi))],
        "frr_ci": [float(np.percentile(frr_s, lo)), float(np.percentile(frr_s, hi))],
        "hter_ci": [float(np.percentile(hter_s, lo)), float(np.percentile(hter_s, hi))],
    }
