"""
End-to-end experiments reported in Sections 11-15 of the manuscript.

1. Segment the Balabit sessions into click-terminated attempts and extract
   the eight-dimensional feature vector (Equations 3-7).
2. Fit the softmax classifier on the training sessions (one session per
   account held out for validation) for each feature arm of the ablation.
3. Split the publicly labeled test sessions, by session, into a calibration
   partition and a test partition. Select the threshold on the calibration
   partition (EER point) and report FAR, FRR and HTER on the test partition.
4. Repeat the Monte Carlo perturbation test and the combined adversarial
   risk at the calibrated threshold.
5. Quantify variability: session-level bootstrap on the primary split and
   repeated random splits.

Usage:
    python run_experiments.py --data-root /path/to/Mouse-Dynamics-Challenge \
                               --output-dir ./artifacts
"""

import argparse
import json
import os

import numpy as np

from src.adversarial import (
    RHO, N_SAMPLES, SLACK_SCALE, combined_risk, monte_carlo, slack_risk,
    weight_row_sum_norm,
)
from src.data_loader import (
    compute_quadrant_midpoints, list_session_files, list_users, load_session,
    segment_into_attempts,
)
from src.evaluate import (
    curve, eer_point, far_frr, operating_point, pool, session_bootstrap,
)
from src.features import build_feature_matrix, extract_features
from src.figures import (
    plot_asr_histogram, plot_entropy_vs_probability, plot_far_frr,
    plot_pca_projection, plot_training_curve,
)
from src.model import Normalizer, SoftmaxAuthenticator, entropy
from src.protocol import labeled_test_sessions, stratified_session_split

SEED = 20260902
ROBUSTNESS_SEEDS = list(range(1, 21))
ETA0 = 0.5
LEARNING_RATE_DECAY = 0.01
N_EPOCHS = 400
TAU_FIXED = 0.75
N_BOOTSTRAP = 2000

ARMS = {
    "full": [0, 1, 2, 3, 4, 5, 6, 7],
    "behavioral": [0, 1, 2, 3],
    "region": [4, 5, 6, 7],
}


def segmenter(path):
    return segment_into_attempts(load_session(path))


def session_feature_matrix(path, x_mid, y_mid):
    rows = [extract_features(seg, x_mid, y_mid) for seg in segmenter(path)]
    rows = [r for r in rows if r is not None]
    return np.array(rows) if rows else np.empty((0, 8))


def fit_arm(columns, X_train, y_train, X_val, y_val, n_classes):
    normalizer = Normalizer().fit(X_train[:, columns])
    Z_train = normalizer.transform(X_train[:, columns])
    Z_val = normalizer.transform(X_val[:, columns])
    model = SoftmaxAuthenticator(len(columns), n_classes)
    history = model.fit(Z_train, y_train, Z_val, y_val, eta0=ETA0,
                        decay=LEARNING_RATE_DECAY, n_epochs=N_EPOCHS)
    return normalizer, model, history, Z_train


def main(data_root, output_dir):
    os.makedirs(output_dir, exist_ok=True)
    training_dir = os.path.join(data_root, "training_files")
    users = list_users(training_dir)
    user_to_label = {u: i for i, u in enumerate(users)}
    n_classes = len(users)

    x_mid, y_mid = compute_quadrant_midpoints(training_dir, users)
    print(f"K={n_classes}, quadrant reference point ({x_mid}, {y_mid})")

    train_sessions, val_sessions = [], []
    for user in users:
        files = list_session_files(training_dir, user)
        train_sessions += [(p, user) for p in files[:-1]]
        val_sessions.append((files[-1], user))
    X_train, y_train = build_feature_matrix(train_sessions, user_to_label,
                                            x_mid, y_mid, segmenter)
    X_val, y_val = build_feature_matrix(val_sessions, user_to_label,
                                        x_mid, y_mid, segmenter)
    print(f"training attempts {X_train.shape[0]}, validation attempts {X_val.shape[0]}")

    sessions = labeled_test_sessions(data_root, users)
    session_X = [session_feature_matrix(p, x_mid, y_mid) for p, _, _ in sessions]
    session_claim = [user_to_label[u] for _, u, _ in sessions]
    session_imp = [imp for _, _, imp in sessions]
    keep = [i for i, X in enumerate(session_X) if len(X) > 0]
    sessions = [sessions[i] for i in keep]
    session_X = [session_X[i] for i in keep]
    session_claim = [session_claim[i] for i in keep]
    session_imp = [session_imp[i] for i in keep]
    print(f"labeled test sessions with usable attempts: {len(sessions)}")

    results = {
        "dataset": {
            "n_identities": n_classes,
            "n_training_attempts": int(X_train.shape[0]),
            "n_validation_attempts": int(X_val.shape[0]),
            "n_labeled_sessions": len(sessions),
            "n_genuine_sessions": int(sum(not f for f in session_imp)),
            "n_impostor_sessions": int(sum(session_imp)),
            "n_genuine_attempts_total": int(sum(len(X) for X, f in zip(session_X, session_imp) if not f)),
            "n_impostor_attempts_total": int(sum(len(X) for X, f in zip(session_X, session_imp) if f)),
        },
        "hyperparameters": {"eta0": ETA0, "decay": LEARNING_RATE_DECAY,
                            "epochs": N_EPOCHS, "tau_fixed": TAU_FIXED,
                            "rho": RHO, "mc_samples": N_SAMPLES,
                            "slack_scale": SLACK_SCALE, "seed": SEED},
        "arms": {},
    }

    primary_cal, primary_test = stratified_session_split(sessions, SEED)
    results["split"] = {
        "n_calibration_sessions": int(len(primary_cal)),
        "n_test_sessions": int(len(primary_test)),
        "n_calibration_genuine_sessions": int(sum(not session_imp[i] for i in primary_cal)),
        "n_calibration_impostor_sessions": int(sum(session_imp[i] for i in primary_cal)),
        "n_test_genuine_sessions": int(sum(not session_imp[i] for i in primary_test)),
        "n_test_impostor_sessions": int(sum(session_imp[i] for i in primary_test)),
    }

    arm_state = {}
    for name, cols in ARMS.items():
        normalizer, model, history, Z_train = fit_arm(
            cols, X_train, y_train, X_val, y_val, n_classes)
        session_scores, session_Z = [], []
        for X, k in zip(session_X, session_claim):
            Z = normalizer.transform(X[:, cols])
            session_Z.append(Z)
            session_scores.append(model.predict_proba(Z)[:, k])
        arm_state[name] = dict(normalizer=normalizer, model=model, history=history,
                               Z_train=Z_train, scores=session_scores, Z=session_Z)

        gen_cal, imp_cal = pool(session_scores, session_imp, primary_cal)
        gen_test, imp_test = pool(session_scores, session_imp, primary_test)
        cal_point = eer_point(gen_cal, imp_cal)
        tau_star = cal_point["tau"]
        test_at_star = operating_point(gen_test, imp_test, tau_star)
        test_at_fixed = operating_point(gen_test, imp_test, TAU_FIXED)
        test_eer_reference = eer_point(gen_test, imp_test)
        boot = session_bootstrap(session_scores, session_imp, primary_test, tau_star,
                                 n_boot=N_BOOTSTRAP, seed=SEED)

        repeated = []
        for s in ROBUSTNESS_SEEDS:
            cal_idx, test_idx = stratified_session_split(sessions, s)
            g_c, i_c = pool(session_scores, session_imp, cal_idx)
            g_t, i_t = pool(session_scores, session_imp, test_idx)
            tau_s = eer_point(g_c, i_c)["tau"]
            op = operating_point(g_t, i_t, tau_s)
            repeated.append((tau_s, op["far"], op["frr"], op["hter"]))
        repeated = np.array(repeated)

        results["arms"][name] = {
            "columns": cols,
            "train_accuracy": history["train_acc"][-1],
            "validation_accuracy": history["val_acc"][-1],
            "final_train_loss": history["train_loss"][-1],
            "final_validation_loss": history["val_loss"][-1],
            "calibration": cal_point,
            "n_calibration_attempts": {"genuine": int(len(gen_cal)), "impostor": int(len(imp_cal))},
            "test_at_calibrated_threshold": test_at_star,
            "test_attempts": {"genuine": int(len(gen_test)), "impostor": int(len(imp_test))},
            "test_bootstrap_ci95": boot,
            "test_at_fixed_threshold": test_at_fixed,
            "test_eer_reference": test_eer_reference,
            "repeated_splits": {
                "n_splits": len(ROBUSTNESS_SEEDS),
                "tau_mean": float(repeated[:, 0].mean()),
                "tau_std": float(repeated[:, 0].std(ddof=1)),
                "far_mean": float(repeated[:, 1].mean()), "far_std": float(repeated[:, 1].std(ddof=1)),
                "frr_mean": float(repeated[:, 2].mean()), "frr_std": float(repeated[:, 2].std(ddof=1)),
                "hter_mean": float(repeated[:, 3].mean()), "hter_std": float(repeated[:, 3].std(ddof=1)),
            },
        }
        print(f"[{name}] train acc {history['train_acc'][-1]:.4f} val acc {history['val_acc'][-1]:.4f} "
              f"tau*={tau_star:.4f} test FAR={test_at_star['far']*100:.2f}% "
              f"FRR={test_at_star['frr']*100:.2f}% HTER={test_at_star['hter']*100:.2f}%")

    rng = np.random.default_rng(SEED)
    for name in ARMS:
        state = arm_state[name]
        model = state["model"]
        tau_star = results["arms"][name]["calibration"]["tau"]
        mc_summary = {}
        for label, tau in (("calibrated", tau_star), ("fixed", TAU_FIXED)):
            imp_p0, imp_asr, gen_asr, max_change = [], [], [], []
            for i in primary_test:
                Z, k = state["Z"][i], session_claim[i]
                p0, asr, mc = monte_carlo(Z, k, model, tau, rng)
                max_change.append(mc)
                if session_imp[i]:
                    imp_p0.append(p0)
                    imp_asr.append(asr)
            p0 = np.concatenate(imp_p0)
            asr = np.concatenate(imp_asr)
            rejected = p0 < tau
            psi = p0[rejected] - tau
            r_slack = slack_risk(psi)
            r_attack = combined_risk(psi, asr[rejected])
            max_change = np.concatenate(max_change)
            w_inf = weight_row_sum_norm(model.W)
            mc_summary[label] = {
                "tau": float(tau),
                "n_impostor_attempts": int(len(p0)),
                "n_rejected": int(rejected.sum()),
                "far_unperturbed": float(np.mean(p0 >= tau)),
                "acceptance_under_perturbation": float(np.mean(asr)),
                "mean_asr_rejected": float(asr[rejected].mean()),
                "share_rejected_with_positive_asr": float(np.mean(asr[rejected] > 0)),
                "mean_slack_risk_rejected": float(r_slack.mean()),
                "mean_combined_risk_rejected": float(r_attack.mean()),
                "weight_inf_norm": w_inf,
                "bound_half": 0.5 * w_inf * RHO,
                "bound_k_over_4": model.n_classes / 4.0 * w_inf * RHO,
                "max_observed_probability_change": float(max_change.max()),
                "mean_max_probability_change": float(max_change.mean()),
            }
            if name == "full" and label == "calibrated":
                plot_asr_histogram(asr[rejected], os.path.join(output_dir, "asr_histogram.pdf"))
        results["arms"][name]["monte_carlo"] = mc_summary
        print(f"[{name}] MC at calibrated tau: mean ASR(rejected) "
              f"{mc_summary['calibrated']['mean_asr_rejected']:.4f}, "
              f"R_attack {mc_summary['calibrated']['mean_combined_risk_rejected']:.4f}")

    full = arm_state["full"]
    model_full = full["model"]
    tau_star_full = results["arms"]["full"]["calibration"]["tau"]
    gen_cal, imp_cal = pool(full["scores"], session_imp, primary_cal)
    gen_test, imp_test = pool(full["scores"], session_imp, primary_test)

    plot_training_curve(full["history"], os.path.join(output_dir, "training_curve.pdf"))
    results["figure_pca"] = plot_pca_projection(
        full["Z_train"], y_train, os.path.join(output_dir, "pca_projection.pdf"), seed=SEED)
    plot_far_frr(curve(gen_test, imp_test), curve(gen_cal, imp_cal), tau_star_full,
                 os.path.join(output_dir, "far_frr_curve.pdf"), tau_fixed=TAU_FIXED)

    probs, ents, count = [], [], 0
    for i in primary_test:
        if session_imp[i]:
            continue
        P = model_full.predict_proba(full["Z"][i])
        probs.append(P[:, session_claim[i]])
        ents.append(entropy(P))
        count += len(P)
        if count > 4000:
            break
    plot_entropy_vs_probability(np.concatenate(probs), np.concatenate(ents),
                                os.path.join(output_dir, "entropy_vs_probability.pdf"),
                                n_classes)

    with open(os.path.join(output_dir, "training_history.json"), "w") as f:
        json.dump(full["history"], f, indent=2)
    with open(os.path.join(output_dir, "results.json"), "w") as f:
        json.dump(results, f, indent=2)
    print(f"results written to {output_dir}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-root", required=True,
                        help="Path to a checkout of the Balabit Mouse-Dynamics-Challenge repository")
    parser.add_argument("--output-dir", default="./artifacts")
    args = parser.parse_args()
    main(args.data_root, args.output_dir)
